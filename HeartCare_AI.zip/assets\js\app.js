console.log('HeartCare AI Initialized');
