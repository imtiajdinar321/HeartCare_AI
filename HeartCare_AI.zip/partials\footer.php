</div>
<footer class="bg-dark text-white pt-4 pb-3 mt-5">
    <div class="container text-center">
        <p class="mb-1">&copy; <?php echo date('Y'); ?> HeartCare AI System. All rights reserved.</p>
        <small class="text-muted">Smart Cardiac Health Monitoring & Doctor Consultation Platform</small>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo SITE_URL; ?>/assets/js/app.js"></script>
</body>
</html>
