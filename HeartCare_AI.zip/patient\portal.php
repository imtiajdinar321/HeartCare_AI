<?php
require_once __DIR__ . '/../config/config.php';
header("Location: dashboard.php");
exit;